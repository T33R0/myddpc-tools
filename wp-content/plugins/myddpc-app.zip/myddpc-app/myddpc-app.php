<?php
/*
Plugin Name:       MyDDPC App

Description:       Loads the integrated MyDDPC React application and provides its REST API endpoints.

Version:           1.1.0

Author:            Rory Teehan
*/

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly.

// 1. =========================================================================
//    SHORTCODE TO DISPLAY THE REACT APP
// =========================================================================
// This creates the [myddpc_app] shortcode. You will place this on a single
// WordPress page (e.g., a new page called "App").
// Its only job is to create a div with the id "root" for React to attach to.

function myddpc_app_shortcode() {
    return '<div id="root"></div>';
}
add_shortcode( 'myddpc_app', 'myddpc_app_shortcode' );

// 2. =========================================================================
//    ENQUEUE REACT APP ASSETS (CSS & JS) - NO-BUILD METHOD
// =========================================================================
// This function loads the compiled JavaScript and CSS from your React build
// process, but ONLY on the page that contains the [myddpc_app] shortcode.

function myddpc_app_enqueue_assets() {
    global $post;
    if ( is_a( $post, 'WP_Post' ) && has_shortcode( $post->post_content, 'myddpc_app' ) ) {
        // --- Load React, ReactDOM, and Babel from a CDN ---
        // This removes the need for any local build process.
        wp_enqueue_script( 'react', 'https://unpkg.com/react@18/umd/react.production.min.js', array(), '18.2.0', true );
        wp_enqueue_script( 'react-dom', 'https://unpkg.com/react-dom@18/umd/react-dom.production.min.js', array('react'), '18.2.0', true );
        wp_enqueue_script( 'babel', 'https://unpkg.com/@babel/standalone/babel.min.js', array(), '7.15.7', true );

        // --- Load our Application CSS and JS ---
        $app_js_url = plugin_dir_url( __FILE__ ) . 'assets/app.js';
        $app_css_url = plugin_dir_url( __FILE__ ) . 'assets/app.css';

        wp_enqueue_style( 'myddpc-react-app-styles', $app_css_url, array(), '1.1.0' );
        // The type="text/babel" is crucial for the in-browser transpilation to work.
        wp_add_inline_script( 'babel', 'document.addEventListener("DOMContentLoaded", function() { Babel.transform(document.querySelector("#myddpc-app-script").innerHTML, { presets: ["react"] }).code; });' );
        wp_enqueue_script( 'myddpc-react-app', $app_js_url, array('react', 'react-dom', 'babel'), '1.1.0', true );
        wp_script_add_data( 'myddpc-react-app', 'type', 'text/babel' );
        wp_script_add_data( 'myddpc-react-app', 'id', 'myddpc-app-script' );

        // --- Pass WordPress data to our React App ---
        wp_localize_script(
            'myddpc-react-app',
            'myddpcAppData',
            [
                'rest_url'    => esc_url_raw( rest_url() ),
                'nonce'       => wp_create_nonce( 'wp_rest' ),
                'is_logged_in'=> is_user_logged_in(),
            ]
        );
    }
}
add_action( 'wp_enqueue_scripts', 'myddpc_app_enqueue_assets' );

// 3. =========================================================================
//    UNIFIED REST API ENDPOINTS
// =========================================================================
// Here, we consolidate all the REST API endpoints from your individual tool
// plugins into a single, organized structure under the /myddpc/v2 namespace.
// The React app will call these endpoints to get data.

function myddpc_app_register_rest_routes() {
    $namespace = 'myddpc/v2';

    // --- FROM: myddpc-dimensions-plugin ---
    register_rest_route( $namespace, '/dimensions/vehicle', [
        'methods'  => 'GET',
        'callback' => 'get_myddpc_vehicle_dimensions_callback',
        'permission_callback' => '__return_true',
    ] );
    register_rest_route( $namespace, '/dimensions/years', [
        'methods' => 'GET',
        'callback' => 'get_myddpc_distinct_years_callback',
        'permission_callback' => '__return_true',
    ] );
    register_rest_route( $namespace, '/dimensions/makes', [
        'methods' => 'GET',
        'callback' => 'get_myddpc_distinct_makes_callback',
        'permission_callback' => '__return_true',
    ] );
    register_rest_route( $namespace, '/dimensions/models', [
        'methods' => 'GET',
        'callback' => 'get_myddpc_distinct_models_callback',
        'permission_callback' => '__return_true',
    ] );
    register_rest_route( $namespace, '/dimensions/trims', [
        'methods' => 'GET',
        'callback' => 'get_myddpc_distinct_trims_callback',
        'permission_callback' => '__return_true',
    ] );

    // --- FROM: myddpc-performance-plugin ---
    register_rest_route( $namespace, '/performance/vehicle', [
        'methods'  => 'GET',
        'callback' => 'get_myddpc_performance_data_callback',
        'permission_callback' => '__return_true',
    ] );
    // Note: The years/makes/models/trims endpoints can be shared with the dimensions tool,
    // so we don't need to re-register them for performance if the logic is identical.

    // --- FROM: myddpc-discover-plugin ---
    register_rest_route( $namespace, '/discover/filters', [
        'methods' => 'GET',
        'callback' => 'get_myddpc_discover_filters_callback',
        'permission_callback' => '__return_true',
    ] );
    register_rest_route( $namespace, '/discover/results', [
        'methods' => 'POST', // POST to handle complex filter objects
        'callback' => 'get_myddpc_discover_results_callback',
        'permission_callback' => '__return_true',
    ] );
    register_rest_route( $namespace, '/discover/vehicle/(?P<id>\d+)', [
        'methods' => 'GET',
        'callback' => 'get_myddpc_discover_vehicle_details_callback',
        'permission_callback' => '__return_true',
        'args' => [
            'id' => [ 'validate_callback' => function($param, $request, $key) { return is_numeric( $param ); } ]
        ],
    ] );
}
add_action( 'rest_api_init', 'myddpc_app_register_rest_routes' );

// 4. =========================================================================
//    API CALLBACK FUNCTIONS
// =========================================================================
// These are the original PHP functions from your plugins that do the actual
// database lookups. We just need to make sure they exist for the REST API
// to call. You can copy the original functions from your old plugins here,
// or ensure the old plugins remain active for their backend logic. For a
// truly unified plugin, copying them here is the cleanest approach.

// --- Callbacks from 'myddpc-dimensions' ---

function get_myddpc_vehicle_dimensions_callback( WP_REST_Request $request ) {
    global $wpdb;
    $params = $request->get_params();
    $year  = isset($params['year']) ? sanitize_text_field($params['year']) : null;
    $make  = isset($params['make']) ? sanitize_text_field($params['make']) : null;
    $model = isset($params['model']) ? sanitize_text_field($params['model']) : null;
    $trim  = isset($params['trim']) ? sanitize_text_field($params['trim']) : null;

    if ( ! $year || ! $make || ! $model || ! $trim ) {
        return new WP_Error( 'bad_request', 'Missing required parameters.', [ 'status' => 400 ] );
    }

    $query = $wpdb->prepare(
        "SELECT `Length (in)`, `Width (in)`, `Height (in)`, `Wheelbase (in)`, `Ground clearance (in)`, `Turning circle (ft)`
        FROM {$wpdb->prefix}vehicle_data WHERE `Year` = %d AND `Make` = %s AND `Model` = %s AND `Trim` = %s",
        $year, $make, $model, $trim
    );
    $result = $wpdb->get_row( $query, ARRAY_A );
    return $result ? new WP_REST_Response( $result, 200 ) : new WP_REST_Response( [], 404 );
}

function get_myddpc_distinct_years_callback() {
    global $wpdb;
    $results = $wpdb->get_col("SELECT DISTINCT Year FROM {$wpdb->prefix}vehicle_data ORDER BY Year DESC");
    return new WP_REST_Response( $results, 200 );
}

function get_myddpc_distinct_makes_callback( WP_REST_Request $request ) {
    global $wpdb;
    $year = $request->get_param('year');
    if (!$year) return new WP_Error( 'bad_request', 'Year is required.', [ 'status' => 400 ] );
    $query = $wpdb->prepare("SELECT DISTINCT Make FROM {$wpdb->prefix}vehicle_data WHERE Year = %d ORDER BY Make ASC", $year);
    $results = $wpdb->get_col($query);
    return new WP_REST_Response( $results, 200 );
}

function get_myddpc_distinct_models_callback( WP_REST_Request $request ) {
    global $wpdb;
    $year = $request->get_param('year');
    $make = $request->get_param('make');
    if (!$year || !$make) return new WP_Error( 'bad_request', 'Year and Make are required.', [ 'status' => 400 ] );
    $query = $wpdb->prepare("SELECT DISTINCT Model FROM {$wpdb->prefix}vehicle_data WHERE Year = %d AND Make = %s ORDER BY Model ASC", $year, $make);
    $results = $wpdb->get_col($query);
    return new WP_REST_Response( $results, 200 );
}

function get_myddpc_distinct_trims_callback( WP_REST_Request $request ) {
    global $wpdb;
    $year = $request->get_param('year');
    $make = $request->get_param('make');
    $model = $request->get_param('model');
    if (!$year || !$make || !$model) return new WP_Error( 'bad_request', 'Year, Make, and Model are required.', [ 'status' => 400 ] );
    $query = $wpdb->prepare("SELECT DISTINCT Trim FROM {$wpdb->prefix}vehicle_data WHERE Year = %d AND Make = %s AND Model = %s ORDER BY Trim ASC", $year, $make, $model);
    $results = $wpdb->get_col($query);
    return new WP_REST_Response( $results, 200 );
}

// --- Callback from 'myddpc-performance' ---
function get_myddpc_performance_data_callback( WP_REST_Request $request ) {
    global $wpdb;
    $params = $request->get_params();
    $year  = isset($params['year']) ? sanitize_text_field($params['year']) : null;
    $make  = isset($params['make']) ? sanitize_text_field($params['make']) : null;
    $model = isset($params['model']) ? sanitize_text_field($params['model']) : null;
    $trim  = isset($params['trim']) ? sanitize_text_field($params['trim']) : null;

    if ( ! $year || ! $make || ! $model || ! $trim ) {
        return new WP_Error( 'bad_request', 'Missing required parameters.', [ 'status' => 400 ] );
    }
    $query = $wpdb->prepare(
        "SELECT
            `Horsepower (HP)`, `Torque (ft-lbs)`, `EPA combined MPG`, `EPA combined MPGe`
        FROM {$wpdb->prefix}vehicle_data
        WHERE `Year` = %d AND `Make` = %s AND `Model` = %s AND `Trim` = %s",
        $year, $make, $model, $trim
    );
    $result = $wpdb->get_row( $query, ARRAY_A );
    return $result ? new WP_REST_Response( $result, 200 ) : new WP_REST_Response( [], 404 );
}

// --- Callbacks from 'myddpc-discover' ---
// (These require the Discover_Query class from your discover plugin)
// For simplicity, let's assume class-discover-query.php is copied into our myddpc-app plugin folder.
if (file_exists(plugin_dir_path(__FILE__) . 'includes/class-discover-query.php')) {
    require_once plugin_dir_path(__FILE__) . 'includes/class-discover-query.php';
}

function get_myddpc_discover_filters_callback($request) {
    if (!class_exists('Discover_Query')) return new WP_Error('class_not_found', 'Discover Query class is missing.', ['status' => 500]);
    $query = new Discover_Query();
    return new WP_REST_Response($query->get_discover_filter_options(), 200);
}

function get_myddpc_discover_results_callback($request) {
    if (!class_exists('Discover_Query')) return new WP_Error('class_not_found', 'Discover Query class is missing.', ['status' => 500]);
    $params = $request->get_json_params();
    $query = new Discover_Query();
    $results = $query->get_discover_results(
        $params['filters'] ?? [],
        $params['limit'] ?? 25,
        $params['offset'] ?? 0,
        $params['sort_by'] ?? 'Year',
        $params['sort_dir'] ?? 'desc'
    );
    return new WP_REST_Response($results, 200);
}

function get_myddpc_discover_vehicle_details_callback($request){
    if (!class_exists('Discover_Query')) return new WP_Error('class_not_found', 'Discover Query class is missing.', ['status' => 500]);
    $id = (int) $request['id'];
    $vehicle_data = Discover_Query::get_vehicle_by_id($id);
    if (empty($vehicle_data)) {
        return new WP_Error('not_found', 'Vehicle not found.', ['status' => 404]);
    }
    return new WP_REST_Response($vehicle_data, 200);
}