// Since we don't have Lucide as a package, we'll create placeholder icons.
// In a production scenario with more time, these could be replaced with actual SVG data.
const Icon = ({ name, className }) => React.createElement('div', { className: icon-placeholder ${className} }, name.charAt(0));

//================================================================================
// 1. CONTEXT FOR STATE MANAGEMENT
//================================================================================
const VehicleContext = createContext();

const VehicleProvider = ({ children }) => {
const [vehicles, setVehicles] = useState([]);
const [discoveryResults, setDiscoveryResults] = useState([]);
const [selectedVehicle, setSelectedVehicle] = useState(null);
const [compareVehicles, setCompareVehicles] = useState([]);
const [loading, setLoading] = useState(true);
const { rest_url, nonce } = window.myddpcAppData;

// This function now fetches your actual garage vehicles from the database via an API endpoint
// We will need to create this endpoint. For now, it uses mock data.
const fetchGarageVehicles = () => {
// MOCK DATA - Replace with API call to a new /garage/vehicles endpoint
const mockVehicles = [
{ id: 1, name: 'Daily Beast', year: 2014, make: 'Audi', model: 'S6', trim: 'Prestige', type: 'Daily Driver', mileage: 95420, lastService: '2024-05-15', nextService: '2024-08-15', totalInvested: 12500, modifications: 12, status: 'operational', buildProgress: 85, engine: '4.0L V8 Turbo', horsepower: 420, torque: 406, recentWork: [{ date: '2024-05-10', type: 'Performance', item: 'ECU Tune', cost: 1200, status: 'completed' }, { date: '2024-04-05', type: 'Maintenance', item: 'Oil Change', cost: 120, status: 'completed' }] },
{ id: 2, name: 'Track Weapon', year: 1999, make: 'BMW', model: 'Z3 Coupe', trim: 'M-Sport', type: 'Project Car', mileage: 178500, lastService: '2024-06-20', nextService: '2024-09-20', totalInvested: 45200, modifications: 28, status: 'maintenance', buildProgress: 65, engine: '2.8L I6', horsepower: 193, torque: 206, recentWork: [{ date: '2024-06-20', type: 'Suspension', item: 'Coilover Install', cost: 2340, status: 'in-progress' }, { date: '2024-05-15', type: 'Performance', item: 'Cold Air Intake', cost: 580, status: 'completed' }] }
];
setVehicles(mockVehicles);
};

const fetchDiscoveryResults = (filters = {}) => {
setLoading(true);
fetch(${rest_url}myddpc/v2/discover/results, {
method: 'POST',
headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': nonce },
body: JSON.stringify({ filters })
})
.then(res => res.json())
.then(data => {
setDiscoveryResults(Array.isArray(data) ? data : []);
setLoading(false);
})
.catch(err => {
console.error("Failed to fetch discovery results:", err);
setLoading(false);
});
};

useEffect(() => {
fetchGarageVehicles();
fetchDiscoveryResults(); // Initial fetch
}, []);

const addToCompare = (vehicle) => {
if (compareVehicles.length < 3 && !compareVehicles.find(v => v.id === vehicle.id)) {
setCompareVehicles([...compareVehicles, vehicle]);
}
};

const removeFromCompare = (vehicleId) => {
setCompareVehicles(compareVehicles.filter(v => v.id !== vehicleId));
};

const clearCompare = () => setCompareVehicles([]);

const value = {
vehicles, discoveryResults, selectedVehicle, setSelectedVehicle,
compareVehicles, addToCompare, removeFromCompare, clearCompare, loading,
fetchDiscoveryResults
};

return React.createElement(VehicleContext.Provider, { value }, children);
};

const useVehicles = () => useContext(VehicleContext);

//================================================================================
// 2. REUSABLE UI COMPONENTS
//================================================================================
const PageHeader = ({ title, subtitle }) => React.createElement('div', { className: 'flex items-center justify-between mb-8' },
React.createElement('div', null,
React.createElement('h1', { className: 'text-3xl font-light text-gray-900 mb-2' }, title),
React.createElement('p', { className: 'text-gray-600' }, subtitle)
)
);

const VehicleCard = ({ vehicle, onClick }) => {
const statusConfig = {
operational: { label: 'Operational', classes: 'bg-green-100 text-green-800' },
maintenance: { label: 'In Service', classes: 'bg-amber-100 text-amber-800' },
default: { label: 'Offline', classes: 'bg-gray-100 text-gray-800' }
};
const currentStatus = statusConfig[vehicle.status] || statusConfig.default;
const daysToService = Math.ceil((new Date(vehicle.nextService) - new Date()) / (1000 * 60 * 60 * 24));

return (
    React.createElement('div', { className: "bg-white rounded-lg border border-gray-200 overflow-hidden hover:shadow-md transition-all duration-200 cursor-pointer group", onClick: onClick },
        React.createElement('div', { className: "p-6 border-b border-gray-100" },
            React.createElement('div', { className: "flex items-start justify-between" },
                React.createElement('div', { className: "flex-1" },
                    React.createElement('div', { className: "flex items-center mb-2" },
                        React.createElement('h3', { className: "text-xl font-medium text-gray-900 mr-3" }, vehicle.name),
                        React.createElement('span', { className: `px-2 py-1 text-xs font-medium rounded-full ${currentStatus.classes}` }, currentStatus.label)
                    ),
                    React.createElement('p', { className: "text-gray-600 font-medium" }, `${vehicle.year} ${vehicle.make} ${vehicle.model}`),
                    React.createElement('p', { className: "text-sm text-gray-500" }, `${vehicle.trim} • ${vehicle.mileage.toLocaleString()} miles`)
                ),
                React.createElement('div', { className: "text-right" },
                    React.createElement('p', { className: "text-sm text-gray-500 mb-1" }, "Type"),
                    React.createElement('p', { className: "font-medium text-gray-900" }, vehicle.type)
                )
            )
        ),
        React.createElement('div', { className: "relative h-48 bg-gradient-to-br from-gray-100 to-gray-200 flex items-center justify-center" }, React.createElement(Icon, { name: "Car", className: "w-20 h-20 text-gray-400" })),
        React.createElement('div', { className: "p-6" },
            React.createElement('div', { className: "grid grid-cols-3 gap-4" },
                React.createElement('div', { className: "text-center" }, React.createElement('p', { className: "text-lg font-light text-gray-900" }, vehicle.modifications), React.createElement('p', { className: "text-xs text-gray-600 uppercase tracking-wide" }, "Mods")),
                React.createElement('div', { className: "text-center" }, React.createElement('p', { className: "text-lg font-light text-gray-900" }, `$${(vehicle.totalInvested / 1000).toFixed(0)}K`), React.createElement('p', { className: "text-xs text-gray-600 uppercase tracking-wide" }, "Invested")),
                React.createElement('div', { className: "text-center" }, React.createElement('p', { className: "text-lg font-light text-gray-900" }, daysToService), React.createElement('p', { className: "text-xs text-gray-600 uppercase tracking-wide" }, "Days to Svc"))
            )
        )
    )
);
};

//================================================================================
// 3. VIEW COMPONENTS (THE DIFFERENT "PAGES")
//================================================================================
const DiscoverView = ({ setActiveView }) => {
const { discoveryResults, addToCompare, loading, fetchDiscoveryResults } = useVehicles();
const [filters, setFilters] = useState({});
const [filterOptions, setFilterOptions] = useState({ makes: [], body_styles: [], drivetrains: [] });
const { rest_url, nonce } = window.myddpcAppData;

useEffect(() =&gt; {
    fetch(`${rest_url}myddpc/v2/discover/filters`, { headers: { 'X-WP-Nonce': nonce } })
        .then(res =&gt; res.json())
        .then(data =&gt; setFilterOptions(data))
        .catch(err =&gt; console.error("Failed to fetch filter options:", err));
}, []);

const handleFilterChange = (filterName, value) =&gt; {
    setFilters(prev =&gt; ({ ...prev, [filterName]: value }));
};

const handleApplyFilters = () =&gt; fetchDiscoveryResults(filters);

return (
    React.createElement('div', { className: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8" },
        React.createElement(PageHeader, { title: "Vehicle Discovery", subtitle: "Find and compare vehicles by specifications and features" }),
        React.createElement('div', { className: "grid grid-cols-1 lg:grid-cols-4 gap-8" },
            React.createElement('div', { className: "lg:col-span-1" },
                 React.createElement('div', { className: "bg-white rounded-lg border border-gray-200 p-6 sticky top-24" },
                    React.createElement('h3', { className: "text-lg font-medium text-gray-900 mb-6" }, "Filters"),
                    React.createElement('div', { className: "space-y-6" },
                        React.createElement('div', null, 
                            React.createElement('label', { className: "block text-sm font-medium text-gray-700 mb-2" }, "Make"),
                            React.createElement('select', { 
                                className: "w-full rounded-lg border border-gray-300 px-3 py-2 text-sm",
                                onChange: (e) =&gt; handleFilterChange('make', e.target.value)
                            },
                            React.createElement('option', { value: "" }, "All Makes"),
                            filterOptions.makes.map(make =&gt; React.createElement('option', { key: make, value: make }, make))
                            )
                        ),
                        React.createElement('button', { onClick: handleApplyFilters, className: "w-full bg-red-600 text-white py-3 px-4 rounded-lg hover:bg-red-700 font-medium" }, "Apply Filters"),
                    )
                )
            ),
            React.createElement('div', { className: "lg:col-span-3" },
                 React.createElement('div', { className: "bg-white rounded-lg border border-gray-200 p-6" },
                    loading ? React.createElement('p', null, 'Loading...') : 
                    React.createElement(React.Fragment, null,
                        React.createElement('p', { className: "text-gray-600 mb-6" }, `${discoveryResults.length} vehicles found`),
                        React.createElement('div', { className: "space-y-4" },
                            discoveryResults.map((vehicle) =&gt; (
                                React.createElement('div', { key: vehicle.id, className: "border border-gray-200 rounded-lg p-4 hover:shadow-sm" },
                                    React.createElement('div', { className: "flex flex-col md:flex-row items-start md:items-center justify-between" },
                                        React.createElement('div', { className: "flex-1 mb-4 md:mb-0" },
                                            React.createElement('h4', { className: "text-lg font-medium text-gray-900 mb-2" }, `${vehicle.Year} ${vehicle.Make} ${vehicle.Model} ${vehicle.Trim}`),
                                            React.createElement('div', { className: "grid grid-cols-2 md:grid-cols-4 gap-x-4 gap-y-2 text-sm text-gray-600" },
                                                React.createElement('div', null, React.createElement('span', { className: "font-medium" }, "Engine:"), ` ${vehicle['Engine Type']}`),
                                                React.createElement('div', null, React.createElement('span', { className: "font-medium" }, "Power:"), ` ${vehicle['Horsepower (HP)']} HP`),
                                                React.createElement('div', null, React.createElement('span', { className: "font-medium" }, "Drive:"), ` ${vehicle.Drivetrain}`),
                                            )
                                        ),
                                        React.createElement('div', { className: "flex items-center space-x-3 w-full md:w-auto" },
                                            React.createElement('button', { onClick: () =&gt; addToCompare(vehicle), className: "flex-1 md:flex-initial px-4 py-2 text-sm border border-gray-300 rounded-lg hover:bg-gray-50" }, "Compare"),
                                            React.createElement('button', { onClick: () =&gt; alert('Save feature coming soon!'), className: "flex-1 md:flex-initial px-4 py-2 text-sm bg-red-600 text-white rounded-lg hover:bg-red-700" }, "Save")
                                        )
                                    )
                                )
                            ))
                        )
                    )
                )
            )
        )
    )
);
};

const CompareView = ({ setActiveView }) => {
const { compareVehicles, removeFromCompare, clearCompare } = useVehicles();

const CompareSlot = ({ vehicle, onRemove }) =&gt; {
    if (vehicle) {
        return (
             React.createElement('div', { className: "bg-white border border-gray-200 rounded-lg overflow-hidden flex flex-col" },
                 React.createElement('div', { className: "p-6 border-b border-gray-100" },
                    React.createElement('div', { className: "flex items-start justify-between mb-4" },
                         React.createElement('div', null,
                            React.createElement('h3', { className: "text-lg font-medium text-gray-900" }, `${vehicle.Year} ${vehicle.Make}`),
                            React.createElement('p', { className: "text-gray-600" }, `${vehicle.Model} ${vehicle.Trim}`)
                        ),
                        React.createElement('button', { onClick: onRemove, className: "text-gray-400 hover:text-gray-600" }, React.createElement(Icon, { name: "X", className: "w-5 h-5" }))
                    )
                ),
                React.createElement('div', { className: "h-48 bg-gradient-to-br from-gray-100 to-gray-200 flex items-center justify-center" }, React.createElement(Icon, { name: "Car", className: "w-16 h-16 text-gray-400" })),
                React.createElement('div', { className: "p-6 flex-grow" },
                     React.createElement('div', { className: "space-y-3" },
                        React.createElement('div', { className: "flex justify-between" }, React.createElement('span', { className: "text-gray-600" }, "Engine:"), React.createElement('span', { className: "font-medium text-right" }, vehicle['Engine Type'])),
                        React.createElement('div', { className: "flex justify-between" }, React.createElement('span', { className: "text-gray-600" }, "Power:"), React.createElement('span', { className: "font-medium" }, `${vehicle['Horsepower (HP)']} HP`)),
                        React.createElement('div', { className: "flex justify-between" }, React.createElement('span', { className: "text-gray-600" }, "Drive:"), React.createElement('span', { className: "font-medium" }, vehicle.Drivetrain)),
                     )
                )
            )
        );
    }
    return (
        React.createElement('div', { className: "h-full flex flex-col items-center justify-center p-6 border-2 border-dashed border-gray-300 rounded-lg bg-gray-50" },
            React.createElement(Icon, { name: "Car", className: "w-16 h-16 text-gray-400 mb-4" }),
            React.createElement('p', { className: "text-gray-500 text-center mb-4" }, "Add Vehicle"),
            React.createElement('button', { onClick: () => setActiveView('discover'), className: "bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700" }, "Browse")
        )
    );
};

return (
    React.createElement('div', { className: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8" },
        React.createElement('div', { className: "flex items-center justify-between mb-8" },
             React.createElement('div', null,
                React.createElement('h1', { className: "text-3xl font-light text-gray-900 mb-2" }, "Vehicle Comparison"),
                React.createElement('p', { className: "text-gray-600" }, "Side-by-side vehicle analysis")
            ),
            compareVehicles.length > 0 && React.createElement('button', { onClick: clearCompare, className: "border border-gray-300 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-50" }, "Clear All")
        ),
        React.createElement('div', { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6" },
            [0, 1, 2].map(slot =&gt; React.createElement(CompareSlot, { key: slot, vehicle: compareVehicles[slot], onRemove: () =&gt; removeFromCompare(compareVehicles[slot].id) }))
        )
    )
);
};

const GarageOverview = ({ setActiveView, setGarageView }) => {
const { vehicles, setSelectedVehicle } = useVehicles();
return (
React.createElement('div', { className: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8" },
React.createElement(PageHeader, { title: "Garage Operations", subtitle: "Vehicle management and build tracking" }),
React.createElement('div', { className: "grid grid-cols-1 lg:grid-cols-2 gap-8" },
vehicles.map((vehicle) => React.createElement(VehicleCard, { key: vehicle.id, vehicle: vehicle, onClick: () => {
setSelectedVehicle(vehicle);
setGarageView('vehicle-detail');
}}))
)
)
);
};

const VehicleDetailView = ({ setGarageView }) => {
const { selectedVehicle } = useVehicles();
if (!selectedVehicle) {
return React.createElement('div', { className: "text-center p-8" }, "No vehicle selected.");
}
return (
React.createElement('div', { className: "max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8" },
React.createElement('button', { onClick: () => setGarageView('overview'), className: "mb-4 text-sm text-red-600 font-medium" }, "← Back to Garage"),
React.createElement(PageHeader, { title: selectedVehicle.name, subtitle: ${selectedVehicle.year} ${selectedVehicle.make} ${selectedVehicle.model} }),
React.createElement('div', { className: "bg-white rounded-lg border border-gray-200 p-6" },
React.createElement('h3', { className: "text-lg font-medium text-gray-900 mb-4" }, "Recent Work"),
React.createElement('ul', { className: "divide-y divide-gray-200" },
selectedVehicle.recentWork.map((work, index) => (
React.createElement('li', { key: index, className: "py-3" },
React.createElement('p', { className: "font-medium" }, ${work.item} (${work.type})),
React.createElement('p', { className: "text-sm text-gray-500" }, Date: ${work.date} | Cost: $${work.cost})
)
))
)
)
)
);
};

const PlaceholderView = ({ title, subtitle, iconName }) => (
React.createElement('div', { className: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8" },
React.createElement(PageHeader, { title: title, subtitle: subtitle }),
React.createElement('div', { className: "bg-white rounded-lg border border-gray-200 p-8 flex items-center justify-center h-96" },
React.createElement('div', { className: "text-center" },
React.createElement(Icon, { name: iconName, className: "w-16 h-16 text-gray-400 mx-auto mb-4" }),
React.createElement('p', { className: "text-gray-500" }, ${title} tools coming soon.)
)
)
)
);

//================================================================================
// 4. MAIN APP COMPONENT & LAYOUT
//================================================================================
const App = () => {
const [activeView, setActiveView] = useState('garage');
const [garageView, setGarageView] = useState('overview'); // 'overview' or 'vehicle-detail'
const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

const navigationItems = [
{ id: 'discover', label: 'Discover', icon: 'Search' },
{ id: 'compare', label: 'Compare', icon: 'Car' },
{ id: 'performance', label: 'Performance', icon: 'BarChart3' },
{ id: 'dimensions', label: 'Dimensions', icon: 'Ruler' },
{ id: 'garage', label: 'Garage', icon: 'Settings' },
];

const handleNavClick = (viewId) => {
setActiveView(viewId);
if (viewId === 'garage') {
setGarageView('overview');
}
setMobileMenuOpen(false);
}

const renderView = () => {
switch (activeView) {
case 'discover': return React.createElement(DiscoverView, { setActiveView });
case 'compare': return React.createElement(CompareView, { setActiveView });
case 'performance': return React.createElement(PlaceholderView, { title: "Performance Analysis", subtitle: "Analyze vehicle performance and efficiency metrics", iconName: "BarChart3" });
case 'dimensions': return React.createElement(PlaceholderView, { title: "Vehicle Dimensions", subtitle: "Analyze vehicle size, fit, and spatial requirements", iconName: "Ruler" });
case 'garage':
return garageView === 'vehicle-detail'
? React.createElement(VehicleDetailView, { setGarageView })
: React.createElement(GarageOverview, { setActiveView, setGarageView });
default: return React.createElement(GarageOverview, { setActiveView, setGarageView });
}
};

return (
React.createElement('div', { className: "min-h-screen bg-gray-50" },
React.createElement('header', { className: "bg-white border-b border-gray-200 sticky top-0 z-50" },
React.createElement('div', { className: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8" },
React.createElement('div', { className: "flex justify-between items-center h-16" },
React.createElement('div', { className: "flex items-center space-x-3" },
React.createElement('div', { className: "relative w-8 h-8" }, React.createElement('div', { className: "absolute inset-0 bg-red-600 rounded-lg" }), React.createElement('div', { className: "absolute inset-1 bg-white rounded-md flex items-center justify-center" }, React.createElement(Icon, { name: "Car", className: "w-4 h-4 text-red-600" }))),
React.createElement('span', { className: "text-xl font-medium text-gray-900" }, "MyDDPC")
),
React.createElement('nav', { className: "hidden md:flex items-center space-x-1" },
navigationItems.map(item => (
React.createElement('button', { key: item.id, onClick: () => handleNavClick(item.id), className: flex items-center px-4 py-2 rounded-lg text-sm font-medium transition-colors ${activeView === item.id ? 'bg-red-50 text-red-700' : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50'} },
React.createElement(Icon, { name: item.icon, className: "w-4 h-4 mr-2" }),
item.label
)
))
),
React.createElement('div', { className: "flex items-center space-x-4" },
React.createElement('div', { className: "flex items-center space-x-2" },
React.createElement('div', { className: "w-8 h-8 bg-gray-200 rounded-full flex items-center justify-center" }, React.createElement(Icon, { name: "User", className: "w-4 h-4 text-gray-600" })),
React.createElement('span', { className: "text-sm font-medium text-gray-700 hidden sm:block" }, "Rory Teehan")
),
React.createElement('button', { onClick: () => setMobileMenuOpen(!mobileMenuOpen), className: "md:hidden p-2 rounded-lg text-gray-600" }, React.createElement(Icon, { name: mobileMenuOpen ? "X" : "Menu", className: "w-5 h-5" }))
)
)
),
mobileMenuOpen && React.createElement('div', { className: "md:hidden border-t border-gray-200 bg-white" },
React.createElement('div', { className: "px-4 py-3 space-y-1" },
navigationItems.map(item => React.createElement('button', { key: item.id, onClick: () => handleNavClick(item.id), className: w-full flex items-center px-3 py-3 rounded-lg text-sm font-medium ${activeView === item.id ? 'bg-red-50 text-red-700' : 'text-gray-600 hover:bg-gray-50'} }, React.createElement(Icon, { name: item.icon, className: "w-5 h-5 mr-3" }), item.label))
)
)
),
React.createElement('main', null, renderView())
)
);
};

// The final render call
const domContainer = document.querySelector('#myddpc-react-root');
const root = ReactDOM.createRoot(domContainer);
root.render(
React.createElement(VehicleProvider, null, React.createElement(App))
);