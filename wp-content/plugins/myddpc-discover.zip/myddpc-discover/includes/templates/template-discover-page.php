<div class="myddpc-discover-container">
    <aside id="discover-filters"></aside>
    <main id="discover-results"></main>
</div>
